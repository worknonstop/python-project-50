#!usr/bin/env python3

from gendiff.cli import display_help


def main():
    display_help()


if __name__ == "__main__":
    main()
